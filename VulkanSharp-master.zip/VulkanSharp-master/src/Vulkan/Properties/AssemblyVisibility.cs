using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Vulkan.Android")]
[assembly: InternalsVisibleTo("Vulkan.Windows")]
[assembly: InternalsVisibleTo("Vulkan.iOS")]
